# Driftwood - Chill Survival Simulator

Third-person survival simulator / RPG for PC and mobile.

## How to play
- Move: WASD (PC) or joystick (mobile)
- Build shelter: E or "Craft" button
- Light fire: F or "Fire" button
- Cook shells: C or "Cook" button
- Inventory updates automatically
- Day/night cycle with shoreline and water animations
